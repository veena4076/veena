package com;


public class tcs {
		static String company_name="tcs";
		static String company_location="hyd";
		String emp_name;
		int emp_id;
		int emp_salary;
		
		public static void developer() {
			System.out.println("designation is developer");
		}
	public void tester() {
		System.out.println("designation is tester");
	}
	public static void main(String[]arg) {
		System.out.println(company_name);
		System.out.println(company_location);
		tcs co=new tcs();
		co.emp_name="sasi";
		System.out.println(co.emp_name);
		co.emp_id=125543;
		System.out.println(co.emp_id);
		co.emp_salary=2500000;
		System.out.println(co.emp_salary);
		
		developer();
		System.out.println("..........");
		tcs co1=new tcs();
		System.out.println(company_name);
		System.out.println(company_location);
		co.emp_name="param";
		System.out.println(company_name);
		co1.emp_id=112233;
		System.out.println(co1.emp_id);
		co1.emp_salary=200000;
		System.out.println(co1.emp_salary);
		co1.tester();
		
		
	}


	}

}
