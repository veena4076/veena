package com;

public class book {
	

public class classbook {
		private String title;
	   private String author;
		private int nopages;
		private int cost;
		public classbook() {
			
		}
		public classbook(String title1,String author,int nopages,int cost) {
			title=title1;
			this.author=author;
			this.cost=cost;
			this.nopages=nopages;
		}
		public void Settitle(String title) {
			this.title=title;
		}
		public String Gettitle() {
			return title;
		}
		public void Setauthor(String author) {
			this.author=author;
		}
		public String Getauthor() {
			return author;
			
		}
		public void Setnopages(int nopages) {
			this.nopages=nopages;
			
		}
		public int Getnopages() {
			return nopages;
			
		}
		public void Setcost(int cost) {
			this.cost=cost;
		}
		public int Getcost() {
			return cost;
			
		}
		public void display() {
			System.out.println("name of the book :"+Gettitle());
			System.out.println("author of the book :"+Getauthor());
			System.out.println("nopages            :"+Getnopages());
			System.out.println("cost of the book   :"+Getcost());
			
		}
		public static void main(String[]args) {
			System.out.println("book details");
			classbook m=new classbook();
			m.Settitle("BREAKING BAD");
			m.Setauthor("HESINBERG");
			m.Setnopages(120);
			m.Setcost(22000);
			m.display();
			System.out.println("---------");
			m.Settitle("ONE PIECE");
			m.Setauthor("ODA SENSEI");
			m.Setnopages(2000);
			m.Setcost(5000);
			m.display();
			System.out.println("-----");
			System.out.println("-------");
			System.out.println("modify the nopages of book");
			System.out.println("-----");
			System.out.println("------");
			m.Setnopages(2001);
			m.display();
			
		}
		 
	}


}
