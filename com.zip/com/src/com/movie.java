
	package com;
	import java.util.Scanner;
	public class tickets {
		static int availabletickets=100;
		public static String book(int quantity) {
			if(quantity<=0) {
				return"tickets quantity shuold be positive.";
		
			}
			availabletickets-=quantity;
			int totalAmount=quantity*50;
			return"successfully booked"+quantity+"tickets.total"+"cost."+totalAmount+".Remaining tickets:"+availabletickets;
		}
		public static String canceltickets(int quanity) {
			int quantity = 0;
			if(quantity<=0) {
				return"cancel quantity should be positive.";
			}
			else if(quantity>(100-availabletickets)) {
				return"cannot cancel more tickets than booked.";
			}
			availabletickets+=quantity;
			return"successfully cancelled"+quantity+"tickets.Remaining tickets:+availabletickets";
			
		}
		public static void main(String[]args) {
			Scanner sc=new  scanner(system.in);
			while(true) {
				System.out.println("select an option:");
				System.out.println("1.Book movie tickets");
				System.out.println("2.cancel tickets");
				System.out.println("3.show available tickets");
				System.out.println("4.exit");
				int option=sc.nextInt();
				switch(option) {
				System.out.print("Enter the number of tickets to book:");
				int quantity=sc.nextInt();
				System.out.println(book(quantity));
				break;
				System.out.print("Enter the number of tickets to cancel:");
				int cancel quantity=sc.nextint();
				
				}
			}
		}

	}


